-- Databricks notebook source
-- MAGIC %python
-- MAGIC dbutils.widgets.removeAll()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.widgets.text("storage","abfss://bronze@adlssmartdata1504.dfs.core.windows.net")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC ## REMOVE DATA (Bronze)
-- MAGIC dbutils.fs.rm(f"{ruta}/tablas/CLIENTES", True)
-- MAGIC dbutils.fs.rm(f"{ruta}/tablas/VENTAS", True)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Creacion de catalog

-- COMMAND ----------

CREATE CATALOG IF NOT EXISTS catalog_dev;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Creacion de Schemas

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS catalog_dev.bronze;
CREATE SCHEMA IF NOT EXISTS catalog_dev.silver;
CREATE SCHEMA IF NOT EXISTS catalog_dev.golden;

-- COMMAND ----------

use catalog ${catalogo}