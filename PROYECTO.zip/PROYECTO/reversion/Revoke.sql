-- Databricks notebook source
REVOKE USE CATALOG ON CATALOG demo_catalog FROM `Dvelopers`;
REVOKE USE SCHEMA ON SCHEMA catalog_dev.bronze FROM `Dvelopers